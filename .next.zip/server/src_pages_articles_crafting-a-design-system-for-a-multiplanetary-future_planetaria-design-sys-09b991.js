"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "src_pages_articles_crafting-a-design-system-for-a-multiplanetary-future_planetaria-design-sys-09b991";
exports.ids = ["src_pages_articles_crafting-a-design-system-for-a-multiplanetary-future_planetaria-design-sys-09b991"];
exports.modules = {

/***/ "./src/pages/articles/crafting-a-design-system-for-a-multiplanetary-future/planetaria-design-system.png":
/*!**************************************************************************************************************!*\
  !*** ./src/pages/articles/crafting-a-design-system-for-a-multiplanetary-future/planetaria-design-system.png ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\"src\":\"/_next/static/media/planetaria-design-system.d4cfce90.png\",\"height\":872,\"width\":1310,\"blurDataURL\":\"/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Fplanetaria-design-system.d4cfce90.png&w=8&q=70\",\"blurWidth\":8,\"blurHeight\":5});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvYXJ0aWNsZXMvY3JhZnRpbmctYS1kZXNpZ24tc3lzdGVtLWZvci1hLW11bHRpcGxhbmV0YXJ5LWZ1dHVyZS9wbGFuZXRhcmlhLWRlc2lnbi1zeXN0ZW0ucG5nLmpzIiwibWFwcGluZ3MiOiI7Ozs7QUFBQSxpRUFBZSxDQUFDLHFPQUFxTyIsInNvdXJjZXMiOlsid2VicGFjazovL3RhaWx3aW5kdWktdGVtcGxhdGUvLi9zcmMvcGFnZXMvYXJ0aWNsZXMvY3JhZnRpbmctYS1kZXNpZ24tc3lzdGVtLWZvci1hLW11bHRpcGxhbmV0YXJ5LWZ1dHVyZS9wbGFuZXRhcmlhLWRlc2lnbi1zeXN0ZW0ucG5nPzA4MjQiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL21lZGlhL3BsYW5ldGFyaWEtZGVzaWduLXN5c3RlbS5kNGNmY2U5MC5wbmdcIixcImhlaWdodFwiOjg3MixcIndpZHRoXCI6MTMxMCxcImJsdXJEYXRhVVJMXCI6XCIvX25leHQvaW1hZ2U/dXJsPSUyRl9uZXh0JTJGc3RhdGljJTJGbWVkaWElMkZwbGFuZXRhcmlhLWRlc2lnbi1zeXN0ZW0uZDRjZmNlOTAucG5nJnc9OCZxPTcwXCIsXCJibHVyV2lkdGhcIjo4LFwiYmx1ckhlaWdodFwiOjV9OyJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/articles/crafting-a-design-system-for-a-multiplanetary-future/planetaria-design-system.png\n");

/***/ })

};
;